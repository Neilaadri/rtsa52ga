RTSA52GA COMMUNITY HUB UPGRADE

Package contents
- index.html: website based on the saved RTSA52GA starter file, with a community feed, comments, and member profiles. Existing account, registration, and vendor profile UI are retained.
- supabase-community-addon.sql: additive SQL for only the new community_profiles, community_posts, and community_comments tables. It does not drop or alter community_registrations or vendor_profiles.

SAFE DEPLOYMENT
1. BACK UP your current working GitHub repository file before replacing anything. Download the current index.html from GitHub or make a Git commit first.
2. In Supabase, open SQL Editor > New query. Review supabase-community-addon.sql, then run it. It creates only the new community tables and policies.
3. Confirm the Supabase URL and publishable key near the start of the script in index.html match the values used by your currently working site. The key in browser code must be the publishable/anon key only, never service_role/secret.
4. IMPORTANT: this package was built from the saved RTSA52GA starter HTML in the project files, not fetched from your live GitHub repository. Compare it with your currently deployed index.html before replacing it so any newer edits on the live site are not lost.
5. Upload the updated index.html to the root of https://github.com/Neilaadri/rtsa52ga (replace the old index.html only after backup), commit the change, and wait for GitHub Pages to rebuild.
6. In Supabase Authentication > URL Configuration, keep Site URL as https://neilaadri.github.io/rtsa52ga/ and make sure that URL is allowed as a redirect. Do not change it to localhost for the live site.
7. Test in a private/incognito browser: sign in, save a display name, create a post, add a comment, sign out, and verify public posts remain visible. Also test registration and vendor profile create/edit/delete.

NOTES
- Community posts, profiles, and comments are public-readable by design; users must be signed in to create content. Members can delete their own posts/comments and edit their own profile.
- User-generated content is rendered with textContent, not injected as HTML.
- The current starter auth signup uses Supabase defaults. Keep the existing email confirmation redirect settings that you already fixed for the live GitHub Pages URL.
- This is a starter upgrade, not a security audit. Review moderation, reporting, rate limits, and privacy policy before inviting the public.
